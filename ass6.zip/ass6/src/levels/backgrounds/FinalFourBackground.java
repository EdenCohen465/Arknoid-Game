package levels.backgrounds;

import biuoop.DrawSurface;
import logics.Sprite;

/**
 * @author Eden Cohen
 * this class incharge of drawing the background of FinalFour level.
 */
public class FinalFourBackground implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {

    }

    @Override
    public void timePassed() {

    }
}
