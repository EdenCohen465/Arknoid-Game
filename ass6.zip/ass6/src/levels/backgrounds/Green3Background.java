package levels.backgrounds;

import biuoop.DrawSurface;
import logics.Sprite;

/**
 * @author Eden Cohen
 * this class incharge of drawing the background of Green 3 level.
 */
public class Green3Background implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {
    }

    @Override
    public void timePassed() {
    }
}
